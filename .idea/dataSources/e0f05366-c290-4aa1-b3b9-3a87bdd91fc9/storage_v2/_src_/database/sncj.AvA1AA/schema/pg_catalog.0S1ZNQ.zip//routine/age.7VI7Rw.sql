create function age(timestamp with time zone)
  returns interval
stable
strict
parallel safe
cost 1
language sql
as $$
select pg_catalog.age(cast(current_date as timestamp with time zone), $1)
$$;

